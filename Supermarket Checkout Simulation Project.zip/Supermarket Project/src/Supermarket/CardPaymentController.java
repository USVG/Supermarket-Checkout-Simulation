package Supermarket;

import Supermarket.observablelists.BasketList;
import Supermarket.observablelists.Item;
import javafx.animation.PauseTransition;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;

import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.text.NumberFormat;
import java.util.Locale;

public class CardPaymentController {

    //GUI Elements
    public Button num1Button;
    public Button num2Button;
    public Button num3Button;
    public Button num4Button;
    public Button num5Button;
    public Button num6Button;
    public Button num7Button;
    public Button num8Button;
    public Button num9Button;
    public Button num0Button;
    public TextField cvcInputBox;
    public Button deleteNumButton;
    public Button doneButton;
    public Label totalLabel;
    public ImageView cardSlotImage;
    public Button scanCardButton;
    public ImageView cardSlotGlowImage;
    public Button payButton;
    public Label totalOfReceipt;
    public Button confirmPaymentButton;
    public Button closeButton;

    //Observable Lists
    @FXML
    private BasketList listOfBasketItem;
    @FXML
    private ListView<Item> basketItemList;

    //Stored Values
    private Double totalOfCheckout;
    NumberFormat nf = NumberFormat.getCurrencyInstance(Locale.UK);
    private int securityInterval = 1;


    @FXML
    public void initialize() {
        listOfBasketItem = new BasketList();
    }

    public void transferTotalOfCheckoutValue(Double total, BasketList basketParameter){

        totalOfCheckout = total;
        listOfBasketItem = basketParameter;

        totalLabel.setText(nf.format(totalOfCheckout));
        totalOfReceipt.setText(nf.format(totalOfCheckout));
        basketItemList.setItems(listOfBasketItem);

    }

    public void scanCard(ActionEvent actionEvent) {
        cardSlotGlowImage.setVisible(true);
        cardSlotImage.setVisible(false);
        PauseTransition pause = new PauseTransition(Duration.millis(500));
        pause.setOnFinished(
                e -> {
                    cardSlotGlowImage.setVisible(false);
                    cardSlotImage.setVisible(true);
                });
        pause.play();
        scanCardButton.setDisable(true);
        num0Button.setDisable(false);
        num1Button.setDisable(false);
        num2Button.setDisable(false);
        num3Button.setDisable(false);
        num4Button.setDisable(false);
        num5Button.setDisable(false);
        num6Button.setDisable(false);
        num7Button.setDisable(false);
        num8Button.setDisable(false);
        num9Button.setDisable(false);
        deleteNumButton.setDisable(false);
        doneButton.setDisable(false);
        closeButton.setDisable(true);

    }

    public void num1Click(ActionEvent actionEvent) {
        if (cvcInputBox.getText().length() < 3) {
            cvcInputBox.appendText("1");
        } else {
            Alert alert = new Alert(Alert.AlertType.INFORMATION, "The CVC field is full", ButtonType.OK);
            alert.showAndWait();
        }
    }

    public void num2Click(ActionEvent actionEvent) {
        if (cvcInputBox.getText().length() < 3) {
            cvcInputBox.appendText("2");
        } else {
            Alert alert = new Alert(Alert.AlertType.INFORMATION, "The CVC field is full", ButtonType.OK);
            alert.showAndWait();
        }
    }

    public void num3Click(ActionEvent actionEvent) {
        if (cvcInputBox.getText().length() < 3) {
            cvcInputBox.appendText("3");
        } else {
            Alert alert = new Alert(Alert.AlertType.INFORMATION, "The CVC field is full", ButtonType.OK);
            alert.showAndWait();
        }
    }

    public void num4Click(ActionEvent actionEvent) {
        if (cvcInputBox.getText().length() < 3) {
            cvcInputBox.appendText("4");
        } else {
            Alert alert = new Alert(Alert.AlertType.INFORMATION, "The CVC field is full", ButtonType.OK);
            alert.showAndWait();
        }
    }

    public void num5Click(ActionEvent actionEvent) {
        if (cvcInputBox.getText().length() < 3) {
            cvcInputBox.appendText("5");
        } else {
            Alert alert = new Alert(Alert.AlertType.INFORMATION, "The CVC field is full", ButtonType.OK);
            alert.showAndWait();
        }
    }

    public void num6Click(ActionEvent actionEvent) {
        if (cvcInputBox.getText().length() < 3) {
            cvcInputBox.appendText("6");
        } else {
            Alert alert = new Alert(Alert.AlertType.INFORMATION, "The CVC field is full", ButtonType.OK);
            alert.showAndWait();
        }
    }

    public void num7Click(ActionEvent actionEvent) {
        if (cvcInputBox.getText().length() < 3) {
            cvcInputBox.appendText("7");
        } else {
            Alert alert = new Alert(Alert.AlertType.INFORMATION, "The CVC field is full", ButtonType.OK);
            alert.showAndWait();
        }
    }

    public void num8Click(ActionEvent actionEvent) {
        if (cvcInputBox.getText().length() < 3) {
            cvcInputBox.appendText("8");
        } else {
            Alert alert = new Alert(Alert.AlertType.INFORMATION, "The CVC field is full", ButtonType.OK);
            alert.showAndWait();
        }
    }

    public void num9Click(ActionEvent actionEvent) {
        if (cvcInputBox.getText().length() < 3) {
            cvcInputBox.appendText("9");
        } else {
            Alert alert = new Alert(Alert.AlertType.INFORMATION, "The CVC field is full", ButtonType.OK);
            alert.showAndWait();
        }
    }

    public void num0Click(ActionEvent actionEvent) {
        if (cvcInputBox.getText().length() < 3) {
            cvcInputBox.appendText("0");
        } else {
            Alert alert = new Alert(Alert.AlertType.INFORMATION, "The CVC field is full", ButtonType.OK);
            alert.showAndWait();
        }
    }

    public void deleteClick(ActionEvent actionEvent) {
        cvcInputBox.setText("");
    }

    public void doneClick(ActionEvent actionEvent) throws InterruptedException {
        String cvc = cvcInputBox.getText();
        PauseTransition pause = new PauseTransition(Duration.millis(1200));
        PauseTransition pause2 = new PauseTransition(Duration.millis(2000));
        if (cvc.length() == 3) {
            cvcInputBox.setText("Processing...");
            pause.setOnFinished(
                    e -> {
                        cvcInputBox.setText("CVC Valid");
                        payButton.setDisable(false);
                        disableNumPad();
                    });
            pause.play();
        }
        else {
            if (securityInterval < 3) {
                cvcInputBox.setText("Processing...");
                securityInterval = securityInterval + 1;
                String securityIntervalForPause = (securityInterval-1)+"";
                pause.setOnFinished(
                        e -> {
                            cvcInputBox.setText("BadCVC " + "Attempt" + securityIntervalForPause);
                            pause2.setOnFinished(
                                    b -> {
                                        cvcInputBox.setText("");
                                    });
                            pause2.play();
                        });
                pause.play();
            } else if (securityInterval >= 3) {

                cvcInputBox.setText("CARD LOCKED");
                Alert alert = new Alert(Alert.AlertType.ERROR, "3 Incorrect Attempts to enter the CVC Security Code \nCard Has Been Locked", ButtonType.OK);
                disableNumPad();
                alert.showAndWait();
                closeButton.setVisible(true);
                closeButton.setDisable(false);

            }



        }

    }

    public void disableNumPad() {

        num0Button.setDisable(true);
        num1Button.setDisable(true);
        num2Button.setDisable(true);
        num3Button.setDisable(true);
        num4Button.setDisable(true);
        num5Button.setDisable(true);
        num6Button.setDisable(true);
        num7Button.setDisable(true);
        num8Button.setDisable(true);
        num9Button.setDisable(true);
        deleteNumButton.setDisable(true);
        doneButton.setDisable(true);

    }

    public void payAmount(ActionEvent actionEvent) {
        totalLabel.setText(nf.format(0));
        payButton.setDisable(true);
        confirmPaymentButton.setDisable(false);
    }

    public void closeAction(ActionEvent actionEvent) {
        Stage stage = (Stage) scanCardButton.getScene().getWindow();
        stage.close();
    }
}
