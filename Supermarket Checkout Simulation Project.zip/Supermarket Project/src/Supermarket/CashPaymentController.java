package Supermarket;

import Supermarket.observablelists.*;
import javafx.animation.PauseTransition;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.text.NumberFormat;
import java.util.List;
import java.util.Locale;

public class CashPaymentController {

    //GUI Elements
    public Button insertCoinButton;
    public Button insertNoteButton;
    public Label totalLabel;
    public Label totalOfReceiptLabel;
    public Label changeLabel;
    public Button collectChangeButton;
    public Button confirmPaymentButton;
    public Button cancelCheckoutButton;
    public ImageView coinSlotGlowImage;
    public ImageView coinSlotImage;
    public ImageView noteSlotImage;
    public ImageView noteSlotGlowImage;

    //Lists
    @FXML
    private CoinList listOfCoins;
    @FXML
    private NoteList listOfNotes;
    @FXML
    private BasketList listOfBasketItem;


    @FXML
    private ListView<Coin> coinList;
    @FXML
    private ListView<Note> noteList;
    @FXML
    private ListView<Item> basketItemList;

    //Stored Values
    private Double totalOfCheckout;
    private Double remainingChange;
    NumberFormat nf = NumberFormat.getCurrencyInstance(Locale.UK);


    public CashPaymentController() {
    }

    @FXML
    public void initialize() {
        remainingChange = 0.0;

        listOfCoins = new CoinList();
        listOfCoins.addItem("5p", 0.05);
        listOfCoins.addItem("10p", 0.10);
        listOfCoins.addItem("20p", 0.20);
        listOfCoins.addItem("50p", 0.50);
        listOfCoins.addItem("£1", 1.00);
        listOfCoins.addItem("£2", 2.00);
        coinList.setItems(listOfCoins);

        listOfNotes = new NoteList();
        listOfNotes.addItem("£5", 5.00);
        listOfNotes.addItem("£10", 10.00);
        listOfNotes.addItem("£20", 20.00);
        listOfNotes.addItem("£50", 50.00);
        noteList.setItems(listOfNotes);

        listOfBasketItem = new BasketList();

        totalOfCheckout = listOfBasketItem.calculateBasketTotal();



    }

    public void insertCoin(ActionEvent actionEvent) {
        Coin selectedCoin = coinList.getSelectionModel().getSelectedItem();
        int selectedCoinIndex = coinList.getSelectionModel().getSelectedIndex();
        if (selectedCoinIndex == -1) {
            Alert alert = new Alert(Alert.AlertType.WARNING, "Please select a coin first", ButtonType.OK);
            alert.showAndWait();
        }
        else {
            if (totalOfCheckout > 0.0) {
                cancelCheckoutButton.setDisable(true);
                coinSlotGlowImage.setVisible(true);
                coinSlotImage.setVisible(false);
                PauseTransition pause = new PauseTransition(Duration.millis(500));
                pause.setOnFinished(
                        e -> {
                            coinSlotGlowImage.setVisible(false);
                            coinSlotImage.setVisible(true);
                        });
                pause.play();
                Double selectedCoinValue = selectedCoin.getCoinValue();
                //IF statements for change
                if ((totalOfCheckout - selectedCoinValue) >= 0.0) {
                    totalOfCheckout = totalOfCheckout - selectedCoinValue;
                    totalLabel.setText(nf.format(totalOfCheckout));
                }
                else if ((totalOfCheckout - selectedCoinValue) < 0.0) {
                    remainingChange = totalOfCheckout - selectedCoinValue;
                    totalOfCheckout = 0.0;
                    totalLabel.setText(nf.format(totalOfCheckout));
                    changeLabel.setText(nf.format(remainingChange));
                    collectChangeButton.setDisable(false);
                }
            }
            else {
            Alert alert = new Alert(Alert.AlertType.INFORMATION, "You have already paid the full amount", ButtonType.OK);
            alert.showAndWait();
            }
        }
    }

    public void insertNote(ActionEvent actionEvent) {
        Note selectedNote = noteList.getSelectionModel().getSelectedItem();
        int selectedNoteIndex = noteList.getSelectionModel().getSelectedIndex();
        if (selectedNoteIndex == -1) {
            Alert alert = new Alert(Alert.AlertType.WARNING, "Please select a note first", ButtonType.OK);
            alert.showAndWait();
        }
        else {
            if (totalOfCheckout > 0.0) {
                cancelCheckoutButton.setDisable(true);
                noteSlotGlowImage.setVisible(true);
                noteSlotImage.setVisible(false);
                PauseTransition pause = new PauseTransition(Duration.millis(500));
                pause.setOnFinished(
                        e -> {
                            noteSlotGlowImage.setVisible(false);
                            noteSlotImage.setVisible(true);
                        });
                pause.play();
                Double selectedNoteValue = selectedNote.getNoteValue();
                //IF statements for change
                if ((totalOfCheckout - selectedNoteValue) >= 0.0) {
                    totalOfCheckout = totalOfCheckout - selectedNoteValue;
                    totalLabel.setText(nf.format(totalOfCheckout));
                }
                else if ((totalOfCheckout - selectedNoteValue) < 0.0) {
                    remainingChange = totalOfCheckout - selectedNoteValue;
                    totalOfCheckout = 0.0;
                    totalLabel.setText(nf.format(totalOfCheckout));
                    changeLabel.setText(nf.format(remainingChange));
                    collectChangeButton.setDisable(false);
                }
            }
            else {
                Alert alert = new Alert(Alert.AlertType.INFORMATION, "You have already paid the full amount", ButtonType.OK);
                alert.showAndWait();
            }
        }
    }

    public void transferTotalOfCheckoutValue(Double total, BasketList basketParameter){
        totalOfCheckout = total;
        listOfBasketItem = basketParameter;

        totalLabel.setText(nf.format(totalOfCheckout));
        totalOfReceiptLabel.setText(nf.format(totalOfCheckout));
        basketItemList.setItems(listOfBasketItem);

    }

    public void collectChange(ActionEvent actionEvent) {
        remainingChange = 0.0;
        changeLabel.setText(nf.format(remainingChange));
        collectChangeButton.setDisable(true);
    }

    public synchronized void confirmPayment(ActionEvent actionEvent) throws InterruptedException {
        if (totalOfCheckout == 0.0) {
            if (remainingChange == 0.0) {
                Stage stage = (Stage) confirmPaymentButton.getScene().getWindow();
                stage.close();
            } else {
                Alert alert = new Alert(Alert.AlertType.INFORMATION, "Please collect your change first", ButtonType.OK);
                alert.showAndWait();
            }
        } else {
            Alert alert = new Alert(Alert.AlertType.WARNING, "You have not paid the full amount", ButtonType.OK);
            alert.showAndWait();
        }

    }


    public void cancelCheckout(ActionEvent actionEvent) {
        Stage stage = (Stage) cancelCheckoutButton.getScene().getWindow();
        stage.close();
    }
}
