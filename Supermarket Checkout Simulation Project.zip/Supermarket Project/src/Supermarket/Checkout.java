package Supermarket;

public class Checkout {

    private String checkoutID;
    private String checkoutTotal;
    private String checkoutPaymentMethod;


    public Checkout(String checkoutID, String checkoutTotal, String checkoutPaymentMethod) {
        this.checkoutID = checkoutID;
        this.checkoutTotal = checkoutTotal;
        this.checkoutPaymentMethod = checkoutPaymentMethod;
    }

    @Override
    public String toString() {
        return "#" + checkoutID + " | " + checkoutTotal + " | " + checkoutPaymentMethod + "\n";
    }
}
