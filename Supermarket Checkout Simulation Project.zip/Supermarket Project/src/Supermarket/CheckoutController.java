package Supermarket;

import Supermarket.observablelists.BasketList;
import Supermarket.observablelists.Item;
import Supermarket.observablelists.ItemList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.IOException;
import java.text.NumberFormat;
import java.util.Locale;

public class CheckoutController {

    //GUI Elements
    @FXML
    public Button scanItemButton;
    @FXML
    public TextField productIDTextField;
    @FXML
    public Label totalLabel;
    public Button removeItemButton;
    public Button payCashButton;
    public Button closeCheckoutButton;
    public Button payCardButton;
    public Button payLoyaltyCard;

    //Item List Observable List Attributes
    @FXML
    private ItemList listOfItems;
    @FXML
    private ListView<Item> itemList;

    //Basket List Observable List Attributes
    @FXML
    private BasketList listOfBasketItems;
    @FXML
    private ListView<Item> basketList;

    //Stored Values
    private int checkoutIDFromOMC;
    private double totalOfCheckout;
    private String paymentMethod;
    private OptionMenuController parent;
    NumberFormat nf = NumberFormat.getCurrencyInstance(Locale.UK);



    @FXML
    public void initialize() {
        paymentMethod = "";
        closeCheckoutButton.setVisible(false);

        listOfItems = new ItemList();
        listOfItems.addItem("P00001","Broom","Large wooden sweeping broom.",2.0);
        listOfItems.addItem("P00002","Speaker","Bluetooth 5.1 Speaker with bass boost.",20.00);
        listOfItems.addItem("P00003","Water Bottle Pack","8 Eve Water Bottles.",3.00);
        listOfItems.addItem("P00004","Hard Hat","Construction-grade hard-hat.",5.00);
        listOfItems.addItem("P00005","Milk","Natural milk from a local farm.",1.50);
        listOfItems.addItem("P00006","Water Gun","Toy water gun with 10m range.",5.00);
        listOfItems.addItem("P00007","Computer Mouse","Logit Branded Wireless Mouse.",10.00);
        listOfItems.addItem("P00008","Folding Chair","Cushioned Compact Foldable Chair.",15.00);
        listOfItems.addItem("P00009","Rice Krispies","Kello branded sugar cereal.",3.50);
        listOfItems.addItem("P00010","Duct Tape","High adhesive black 3M duct tape.",1.00);
        itemList.setItems(listOfItems);

        listOfBasketItems = new BasketList();
        basketList.setItems(listOfBasketItems);

    }

    public void scanItem(ActionEvent actionEvent){
        Item itemSearched;
        String findID = productIDTextField.getText().toUpperCase();
        itemSearched = listOfItems.searchItemViaID(findID);

        try {
            if (findID.equals(itemSearched.getProductID())) {

                itemList.getSelectionModel().select(itemSearched);
                itemList.scrollTo(itemSearched);

                //Grab Attributes
                listOfBasketItems.addItem(itemSearched);
                totalLabel.setText(nf.format(listOfBasketItems.calculateBasketTotal()));

                payCashButton.setDisable(false);
                payCardButton.setDisable(false);
                payLoyaltyCard.setDisable(false);

            }

        } catch(NullPointerException nPE) {
            Alert alert = new Alert(Alert.AlertType.WARNING, "Invalid Product Code Entered", ButtonType.OK);
            alert.showAndWait();
        }

    }

    public void enterProductID(ActionEvent actionEvent) {
    }

    public void removeItem(ActionEvent actionEvent) {
        int selectedBasketItem = basketList.getSelectionModel().getSelectedIndex();
        if (selectedBasketItem == -1) {
            Alert alert = new Alert(Alert.AlertType.WARNING, "Select an item from the basket to remove first", ButtonType.OK);
            alert.showAndWait();
        }
        else {
            Item e = basketList.getSelectionModel().getSelectedItem();
            listOfBasketItems.remove(e);
            totalLabel.setText(nf.format(listOfBasketItems.calculateBasketTotal()));
        }

    }

    public void clickPayCash(ActionEvent actionEvent) throws IOException {
        Double totalParsed = Double.parseDouble(totalLabel.getText().replace("£", ""));
        if (totalParsed <= 0.0) {
            Alert alert = new Alert(Alert.AlertType.WARNING, "Basket is empty", ButtonType.OK);
            alert.show();
        } else {
            disableButtonsForPayment();
            FXMLLoader loader = new FXMLLoader(getClass().getResource("cashPayment.fxml"));
            Scene paymentScene = new Scene(loader.load());
            CashPaymentController cPController = loader.getController();
            totalOfCheckout = listOfBasketItems.calculateBasketTotal();
            cPController.transferTotalOfCheckoutValue(totalOfCheckout, listOfBasketItems);
            basketList.setDisable(true);
            paymentMethod = "Cash Payment";

            Stage paymentStage = new Stage();
            paymentStage.setScene(paymentScene);
            paymentStage.initModality(Modality.APPLICATION_MODAL);
            paymentStage.setWidth(700);
            paymentStage.setHeight(525);
            paymentStage.setTitle("Cash Payment #"+checkoutIDFromOMC);
            paymentStage.show();
        }



    }

    public void clickPayCard(ActionEvent actionEvent) throws IOException {
        Double totalParsed = Double.parseDouble(totalLabel.getText().replace("£", ""));
        if (totalParsed <= 0.0) {
            Alert alert = new Alert(Alert.AlertType.WARNING, "Basket is empty", ButtonType.OK);
            alert.show();
        } else {
            disableButtonsForPayment();
            FXMLLoader loader = new FXMLLoader(getClass().getResource("cardPayment.fxml"));
            Scene paymentScene = new Scene(loader.load());
            CardPaymentController cPController = loader.getController();
            totalOfCheckout = listOfBasketItems.calculateBasketTotal();
            cPController.transferTotalOfCheckoutValue(totalOfCheckout, listOfBasketItems);
            basketList.setDisable(true);
            paymentMethod = "Card Payment";

            Stage paymentStage = new Stage();
            paymentStage.setScene(paymentScene);
            paymentStage.initModality(Modality.APPLICATION_MODAL);
            paymentStage.setWidth(700);
            paymentStage.setHeight(525);
            paymentStage.setTitle("Card Payment #" + checkoutIDFromOMC);
            paymentStage.show();
        }
    }

    public void clickPayLoyalty(ActionEvent actionEvent) throws IOException {

        Double totalParsed = Double.parseDouble(totalLabel.getText().replace("£", ""));
        if (totalParsed <= 0.0) {
            Alert alert = new Alert(Alert.AlertType.WARNING, "Basket is empty", ButtonType.OK);
            alert.show();
        } else {
            disableButtonsForPayment();
            FXMLLoader loader = new FXMLLoader(getClass().getResource("loyaltyPayment.fxml"));
            Scene paymentScene = new Scene(loader.load());
            LoyaltyPaymentController cPController = loader.getController();
            totalOfCheckout = listOfBasketItems.calculateBasketTotal();
            cPController.transferTotalOfCheckoutValue(totalOfCheckout, listOfBasketItems);
            basketList.setDisable(true);
            paymentMethod = "Point Payment";

            Stage paymentStage = new Stage();
            paymentStage.setScene(paymentScene);
            paymentStage.initModality(Modality.APPLICATION_MODAL);
            paymentStage.setWidth(700);
            paymentStage.setHeight(525);
            paymentStage.setTitle("Point Card Payment #" + checkoutIDFromOMC);
            paymentStage.show();
        }
    }

    public void closeCheckout(ActionEvent actionEvent) {
        createNewCheckoutInstance(checkoutIDFromOMC+"",nf.format(totalOfCheckout), paymentMethod);
        Alert alert = new Alert(Alert.AlertType.INFORMATION, "Thank you for shopping with us\n\nCheckout ID: #"+checkoutIDFromOMC);
        alert.show();

        Stage stage = (Stage) closeCheckoutButton.getScene().getWindow();
        stage.close();

    }

    public void transferCheckoutID(int checkoutID) {
        checkoutIDFromOMC = checkoutID;

    }

    public void disableButtonsForPayment() {
        itemList.setDisable(true);
        productIDTextField.setDisable(true);
        scanItemButton.setDisable(true);
        removeItemButton.setDisable(true);
        payCashButton.setDisable(true);
        payCardButton.setDisable(true);
        payLoyaltyCard.setDisable(true);
        closeCheckoutButton.setVisible(true);
    }

    public void createNewCheckoutInstance(String checkoutID, String checkoutTotal, String checkoutPaymentMethod) {
        Checkout c = new Checkout(checkoutID, checkoutTotal, checkoutPaymentMethod);
        parent.addCheckoutToList(c);
    }

    public void setParent(OptionMenuController p){
        // Remember the reference to the parent GUI, then we can call its methods
        parent = p;
    }

}
