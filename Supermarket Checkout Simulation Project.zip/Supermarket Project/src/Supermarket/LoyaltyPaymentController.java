package Supermarket;

import Supermarket.observablelists.BasketList;
import Supermarket.observablelists.Item;
import javafx.animation.PauseTransition;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Locale;

public class LoyaltyPaymentController {

    //GUI Elements

    public Label totalLabel;
    public Button confirmPaymentButton;
    public Button cancelCheckoutButton;
    public Label totalOfReceiptLabel;
    public TextField cardIDTextField;
    public Button validateCodeButton;

    //Lists
    @FXML
    private BasketList listOfBasketItem;
    @FXML
    private ListView<Item> basketItemList;


    //Stored Values
    private Double totalOfCheckout;
    NumberFormat nf = NumberFormat.getCurrencyInstance(Locale.UK);
    private ArrayList<String> listOfLoyaltyCodes = new ArrayList<>();

    public void initialize() {

        listOfLoyaltyCodes.add("4444-5555-6666");
        listOfLoyaltyCodes.add("1111-2222-3333");
        listOfLoyaltyCodes.add("1122-3344-5566");
        listOfBasketItem = new BasketList();

    }

    public void validateCode(ActionEvent actionEvent) {
        String codeEntered = cardIDTextField.getText();
        PauseTransition pause = new PauseTransition(Duration.millis(1200));
        cancelCheckoutButton.setDisable(true);
        if (confirmPaymentButton.isDisabled()) {
            for (String s : listOfLoyaltyCodes) {
                if (s.equals(codeEntered)) {
                    cardIDTextField.setText("Processing...");
                    pause.setOnFinished(
                            e -> {
                                cardIDTextField.setText("CODE VALID");
                                validateCodeButton.setDisable(false);
                                totalLabel.setText(nf.format(0.0));
                                confirmPaymentButton.setDisable(false);
                            });
                    pause.play();
                }
            }
        }
        else {
            cardIDTextField.setText("CODE INVALID");
            pause.setOnFinished(
                    e -> {
                        cardIDTextField.setText(codeEntered);
                    });
            pause.play();
        }
    }

    public void closeWindow(ActionEvent actionEvent) {
        Stage stage = (Stage) confirmPaymentButton.getScene().getWindow();
        stage.close();
    }


    public void transferTotalOfCheckoutValue(Double total, BasketList basketParameter){
        totalOfCheckout = total;
        listOfBasketItem = basketParameter;

        totalLabel.setText(nf.format(totalOfCheckout));
        totalOfReceiptLabel.setText(nf.format(totalOfCheckout));
        basketItemList.setItems(listOfBasketItem);

    }


}
