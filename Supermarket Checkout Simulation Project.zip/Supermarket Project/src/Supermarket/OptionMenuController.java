package Supermarket;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.*;
import java.util.ArrayList;
import java.util.Random;

public class OptionMenuController implements Serializable{


    public Button exitButton;
    public Button createCheckoutButton;
    public ImageView headerImage;
    public Button viewCheckoutButton;
    public Label label;
    public Button saveButton;
    public Button loadButton;

    private int checkoutID;
    private ArrayList<Checkout> checkoutList = new ArrayList<Checkout>();
    private ArrayList<Checkout> permanentCheckoutList = new ArrayList<Checkout>();
    private String largeString = "";
    private Integer checkoutCounter = 0;

    public void createCheckout(ActionEvent actionEvent) throws IOException {
        checkoutID = newCheckoutID(100000, 999999);

        FXMLLoader loader = new FXMLLoader(getClass().getResource("checkout.fxml"));
        Scene checkoutScene = new Scene(loader.load());
        CheckoutController cPController = loader.getController();
        cPController.transferCheckoutID(checkoutID);
        cPController.setParent(OptionMenuController.this);

        Stage checkoutStage = new Stage();
        checkoutStage.setScene(checkoutScene);
        checkoutStage.initModality(Modality.NONE);
        checkoutStage.setWidth(700);
        checkoutStage.setHeight(525);
        checkoutStage.setTitle("Checkout #"+checkoutID);
        checkoutStage.show();
    }

    public int newCheckoutID(int min, int max) {
        Random rand = new Random();
        return rand.nextInt(max - min) + min;
    }

    public void addCheckoutToList(Checkout c) {
        checkoutList.add(c);
        permanentCheckoutList.add(c);
        label.setText(c.toString());
    }

    public String loopThroughList() {
        for (Checkout c : checkoutList) {
            checkoutCounter = checkoutCounter + 1;
            largeString = largeString.concat(checkoutCounter+" "+c.toString());

        }
        checkoutList.clear();
        return largeString;

    }

    public void viewCheckouts(ActionEvent actionEvent) {

        Alert alert = new Alert(Alert.AlertType.NONE, loopThroughList(), ButtonType.CLOSE);
        alert.setTitle("View Checkouts");
        alert.setHeaderText("Checkout List");
        alert.showAndWait();

    }

    public void save(ActionEvent actionEvent) throws IOException {
        try {
            checkoutCounter = 1;
            BufferedWriter bw = new BufferedWriter(new FileWriter("CheckoutLog.txt"));
            for (Checkout c : permanentCheckoutList) {
                checkoutCounter = checkoutCounter + 1;
                bw.write(checkoutCounter + " " +c.toString());
            }
            bw.close();
            Alert alert = new Alert(Alert.AlertType.INFORMATION,
                    "Data Saved Successfully", ButtonType.OK);
            alert.showAndWait();
        } catch (Exception e){
            Alert alert = new Alert(Alert.AlertType.WARNING,
                    "Error Saving Data", ButtonType.OK);
            alert.showAndWait();
        }

    }

    public void load(ActionEvent actionEvent) throws IOException, ClassNotFoundException {
        try {
            BufferedReader br = new BufferedReader(new FileReader("CheckoutLog.txt"));
            largeString = "";
            String s = new String();

            //This line of code was taken from a Stack Overflow Post, it has been referenced in the report
            for (String line; (line = br.readLine()) != null; s += line + "\n");
            //Stack Overflow. (2016). How to easily convert a BufferedReader to a String?. user2665773.

            br.close();
            label.setText(s);
            largeString = s;
            Alert alert = new Alert(Alert.AlertType.INFORMATION,
                    "Data Loaded Successfully", ButtonType.OK);
            alert.showAndWait();
        } catch (Exception e){
            Alert alert = new Alert(Alert.AlertType.WARNING,
                    "Error Loading Data", ButtonType.OK);
            alert.showAndWait();
        }
    }


    public void exit(ActionEvent actionEvent) {
        Stage stage = (Stage) exitButton.getScene().getWindow();
        stage.close();

    }


}
