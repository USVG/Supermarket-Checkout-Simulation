package Supermarket.observablelists;

import com.sun.javafx.collections.ObservableListWrapper;
import javafx.collections.FXCollections;

import java.util.Iterator;

public class BasketList extends ObservableListWrapper<Item> {

    public BasketList() {
        super(FXCollections.observableArrayList());
    }

    public void addItem(Item item) {
        super.add(item);
    }

    public Double calculateBasketTotal() {
        Double total = 0.0;
        for (Iterator<Item> it = super.iterator(); it.hasNext(); ) {
            Item i = it.next();
            total += i.getPrice();

        }
        return total;
    }


}
