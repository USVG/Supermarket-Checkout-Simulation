/**
package Supermarket.observablelists;

import static org.junit.jupiter.api.Assertions.*;

class BasketListTest {
    private BasketList bl;
    private BasketList bl2;

    @org.junit.jupiter.api.BeforeEach
    void setUp() {
        bl = new BasketList();
        bl2 = new BasketList();

        Item item1 = new Item("P00020","Cheese Block",
                "High quality cheddar cheese block", 2.0);
        Item item2 = new Item("P00030","Milk Carton",
                "Freshly Sourced Milk 500ml", 1.0);
        Item item3 = new Item("P00040","Earphones",
                "JBB Branded Stereo Earphones", 10.0);
        Item item4 = new Item("P00050","USB Flash Drive",
                "16GB SandSpin USB Flash Drive", 6.0);

        bl.addItem(item1);
        bl.addItem(item2);
        bl.addItem(item2);

        bl2.addItem(item1);
        bl2.addItem(item2);
        bl2.addItem(item3);
        bl2.addItem(item4);

    }

    @org.junit.jupiter.api.Test
    void addItem() {
    }

    @org.junit.jupiter.api.Test
    void calculateBasketTotal() {
        double testResult = bl.calculateBasketTotal();
        double testResult2 = bl2.calculateBasketTotal();
        assertEquals(4.0, testResult);
        assertNotEquals(10.0, testResult);
        assertNotEquals(0.0, testResult);

        assertEquals(19.0, testResult2);
        assertNotEquals(16.0, testResult2);
        assertNotEquals(19.2, testResult2);

    }
}
 **/