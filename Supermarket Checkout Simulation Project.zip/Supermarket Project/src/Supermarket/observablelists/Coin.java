package Supermarket.observablelists;

public class Coin {

    private String coinName;
    private Double coinValue;

    public Coin(String coinName, Double coinValue) {
        this.coinName = coinName;
        this.coinValue = coinValue;
    }

    public Double getCoinValue() {
        return coinValue;
    }

    @Override
    public String toString() {
        return coinName;
    }
}
