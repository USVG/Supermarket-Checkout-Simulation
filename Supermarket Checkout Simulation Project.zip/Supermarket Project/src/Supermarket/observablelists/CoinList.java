package Supermarket.observablelists;

import com.sun.javafx.collections.ObservableListWrapper;
import javafx.collections.FXCollections;

public class CoinList extends ObservableListWrapper<Coin>{

    public CoinList() {
        super(FXCollections.observableArrayList());
    }

    public void addItem(String coinName, Double coinValue) {
        super.add(new Coin(coinName, coinValue));
    }


}
