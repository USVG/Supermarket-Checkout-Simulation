package Supermarket.observablelists;

import java.io.*;

public class Item implements Serializable {
    private String productID;
    private String name;
    private String description;
    private Double price;

    public Item(String productID, String name, String description, Double price) {
        this.productID = productID;
        this.name = name;
        this.description = description;
        this.price = price;
    }

    public String getProductID() {
        return productID;
    }

    public Double getPrice() {
        return price;
    }
    
    @Override
    public String toString() {
        return productID + " | " + name + "\n" + price + " | " + description;
    }
}
