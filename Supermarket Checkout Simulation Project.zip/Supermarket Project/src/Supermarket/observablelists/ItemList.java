package Supermarket.observablelists;

import com.sun.javafx.collections.ObservableListWrapper;
import javafx.collections.FXCollections;

public class ItemList extends ObservableListWrapper<Item> {

    public ItemList() {
        super(FXCollections.observableArrayList());
    }

    public void addItem(String productID, String name, String description, Double price) {
        super.add(new Item(productID, name, description, price));
    }


    public Item searchItemViaID(String productID) {
        Item selectedProduct;
        int indexLocation = -1;

        for (int i = 0; i < super.size(); i++) {
            selectedProduct = super.get(i);

            if (selectedProduct.getProductID().equals(productID)){
                indexLocation = i;
                break;
            }
        }

        if (indexLocation == -1) {
            return null;
        } else {
            return super.get(indexLocation);
        }
    }


}
