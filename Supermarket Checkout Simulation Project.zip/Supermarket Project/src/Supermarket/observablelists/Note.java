package Supermarket.observablelists;

public class Note {

    private String noteName;
    private Double noteValue;

    public Note(String noteName, Double noteValue) {
        this.noteName = noteName;
        this.noteValue = noteValue;
    }

    public Double getNoteValue() {
        return noteValue;
    }

    @Override
    public String toString() {
        return noteName;
    }
}
