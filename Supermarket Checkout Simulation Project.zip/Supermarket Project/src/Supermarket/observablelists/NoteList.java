package Supermarket.observablelists;

import com.sun.javafx.collections.ObservableListWrapper;
import javafx.collections.FXCollections;

public class NoteList extends ObservableListWrapper<Note>{

    public NoteList() {
        super(FXCollections.observableArrayList());
    }

    public void addItem(String noteName, Double noteValue) {
        super.add(new Note(noteName, noteValue));
    }
}
